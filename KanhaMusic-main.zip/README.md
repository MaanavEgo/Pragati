# 𝐒𝐇𝐎𝐍𝐀 𝐌𝐔𝐒𝐈𝐂

<h1 align="center"
 
### 🚩🚩 जय बजरंग बली 🚩🚩
<h1 align="center"
  
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">
<img src="https://readme-typing-svg.herokuapp.com?color=FF0085&width=620&lines=🍁+🚩+𝗣𝗢𝗪𝗘𝗥𝗘𝗗+𝗕𝗬+𝐇𝐀𝐑𝐒𝐇+𝗞𝗜𝗡𝗚+𝐌𝐀𝐃𝐇𝐔𝐁𝐀𝐍𝐈+🚩+🍁"></b></h3>
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">
<h1 align="center"><b>𝐓ᴇᴀᴍ 𝐒ʜᴏɴᴀ 𝐁ᴏᴛs</b></h1>
<p align="center"><a href="https://Theshonaqueen"><img src="https://files.catbox.moe/fv47sa.jpg" width="400"></a></p>
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

</p>
ʀᴀᴜsʜᴀɴ
<p align="center">
<b>𝗗𝗘𝗣𝗟𝗢𝗬𝗠𝗘𝗡𝗧 𝗠𝗘𝗧𝗛𝗢𝗗𝗦</b>
</p>

<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʜᴇʀᴏᴋᴜ 」─
</h3>

<p align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/ayushprincekmr03-boop/MUSIC-V2"> <img src="https://img.shields.io/badge/Deploy%20On%20Heroku-green?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>


<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʟᴏᴄᴀʟ ʜᴏsᴛ / ᴠᴘs 」─
</h3>

- Get your [Necessary Variables](https://github.com/TEAMPURVI/ALPHA_MUSIC/blob/main/sample.env)
- Upgrade and Update by :
`sudo apt-get update && sudo apt-get upgrade -y`
- Install Ffmpeg & Python by :
`sudo apt-get install python3-pip ffmpeg -y`
- Install pip by :
`sudo pip3 install -U pip`
- Install Node js by :
`curl -fssL https://deb.nodesource.com/setup_19.x | sudo -E bash - && sudo apt-get install nodejs -y && npm i -g npm`
- Clone the repository by :
`git clone https://github.com/TEAMPURVI/ALPHA_MUSIC && cd ALPHA_MUSIC`
- Install requirements by :
`pip3 install -U -r requirements.txt`
- Fill your variables in the env by :
`vi sample.env`<br>
Press `I` on the keyboard for editing env<br>
Press `Ctrl+C` when you're done with editing env and `:wq` to save the env<br>
- Rename the env file by :
`mv sample.env .env`
- Install tmux to keep running your bot when you close the terminal by :
`sudo apt install tmux && tmux`
- Finally run the bot by :
`bash start`
- For getting out from tmux session : Press `Ctrl+b` and then `d`<br>
━━━━━━━━━━━━━━━━━━━━


[![Contributors](https://contrib.rocks/image?repo=TEAMPURVI/ALPHA_MUSIC)](https://github.com/TEAMPURVI/ALPHA_MUSIC/graphs/contributors)

### Contact :
<a href="https://t.me/Theshonaqueen"><img title="Telegram" src="https://img.shields.io/badge/Telegram-%23000000.svg?&style=for-the-badge&logo=telegram&logoColor=61DAFB"></a>

<a href="https://instagram.com/Theshonaqueen"><img title="Instagram" src="https://img.shields.io/badge/instagram-%23E4405F.svg?&style=for-the-badge&logo=instagram&logoColor=white"></a>
